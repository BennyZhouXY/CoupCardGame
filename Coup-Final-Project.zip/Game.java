/**
* A Game object with a turn number, number of alive players, scoreboard, array of players, array of alive players, and deck.
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

import java.io.*;
import java.util.*;

class Game{

  //Declare variables
  private int turnNum, numAlivePlayers;
  private Player[] scoreboard;
  private Player[] players = new Player[4]; //4 player game
  private Player[] alivePlayers = new Player[4];
  private int nextPlayer; // index of the next player to go
  private Deck deck = new Deck(); // 15 card deck
  private Scanner input = new Scanner(System.in);
  private Boolean loadFail;
  private int choice;
  private int target;

  // Variables to check the deck
  private int numAmbassador = 0;
  private int numAssassin = 0;
  private int numCaptain = 0;
  private int numContessa = 0;
  private int numDuke = 0;

  /** Creates a game, and starts the game (shuffles deck, makes players, etc.)
   */

  public Game() {
    
    // Asks if user wants to load a saved game or start a new game
    System.out.print("Welcome to Coup!\n(1) Start a new game \n(2) Load the saved game\n");
    
    // loadFail is initialized to false
    loadFail = false;
    
    // Checks if input is valid
    do {    
      
      try{ // checks if not int
        System.out.print("Select the number beside the option: ");
        choice = Integer.parseInt(input.nextLine()); 
      } catch (NumberFormatException ex) {
      
      }

    } while (!((choice == 1) || (choice == 2))); //Check for valid input (integer from 1-2)
    
    
    // Attempt to load game if user chooses to
    if (choice == 2) {
      players = new Player[4];
      load();

      // If loading fails, get user to start a new game
      if (loadFail) {
        choice = 1;
      }
    }

    // Starts a new game
    if (choice == 1) {

      // Shuffles the deck;
      deck.shuffle();

      // Gets user to enter their name without commas because commas will interfere with load
      System.out.print("Enter your name (no commas) : ");
      String name = input.nextLine();

      // Ensures their name does not have commas
      while (name.indexOf(',') >= 0) {

        // Prints error message and gets user to enter a new comma-less name
        System.out.print("Your name had a comma. Enter a name without commas: ");
        name = input.nextLine();
      }

      // Creates the human player by 
      HumanPlayer human = new HumanPlayer(deck.draw(), deck.draw(), name);

      // Creates the three ai's
      PassiveAI ai1 = new PassiveAI(deck.draw(), deck.draw(), "Passive AI Mecha\'thun");
      AggressiveAI ai2 = new AggressiveAI(deck.draw(), deck.draw(), "Aggressive AI Gonk The Raptor");
      WildcardAI ai3 = new WildcardAI(deck.draw(), deck.draw(), "Wildcard AI Temporus");

      // Player order is human, passive ai, aggressive ai, then wildcard ai
      this.players = new Player[]{human, ai1, ai2, ai3};

      // For loop changes the name of one of the bots if the human player picks the same name as them
      for (int i = 1; i < 4; i++) {
        if (name.equals(players[i].getName())) {
          System.out.println("You picked the same name as one of the bots, so their name has been changed!");
          players[i].setName("Millhouse Manastorm");
        }
      }

      // Initialization of variables
      this.alivePlayers = this.players;
      this.numAlivePlayers = 4;
    }

    this.nextPlayer = 0;
  }



  //Methods
  
  /** Updates the game state after every turn
   */
  
  public void endTurn() {

    // Checks all of the players who were alive before the start of the turn
    for (int i = 0; i < alivePlayers.length; i++) {
      
      // Checks if each player has died or not
      if (alivePlayers[i].getCard1().toString().equals("Dead") && alivePlayers[i].getCard2().toString().equals("Dead")) {

        // Updates the number of alive players
        this.alivePlayers[i].setIsAlive(false);
        System.out.println("\n" + alivePlayers[i].getName() + " got eliminated during this turn!\n");
        this.alivePlayers[i].setRank(this.numAlivePlayers);
        this.numAlivePlayers--;
      }
    }

    // Creates temp array and fills it with all of the remaining alive players
    Player[] temp = new Player[numAlivePlayers];
    int index = 0;

    // Copies the alive players into temp
    for (int i = 0; i < alivePlayers.length; i++) {

      // Checks if each player in alivePlayers is still alive
      if (alivePlayers[i].getIsAlive()) {

        // Copies the player into temp
        temp[index] = this.alivePlayers[i];
        index++;
      }
    }

    // Copies temp back into alive players
    alivePlayers = temp;

    // Increases the index of the next player to go
    nextPlayer++;
    
    // Checks if nextPlayer is going to be out of bounds and if it is, resets it to 0
    if (nextPlayer >= numAlivePlayers) {
      nextPlayer = 0;

      // Increases the turn number
      turnNum++;
    }
  }



  /** Saves the game
   */

  public void save() {
    
    // Creates strings and string arrays to store the information about the players and game
    String[] info = new String[5];
    String otherInfo;

    // Copies the information of the players into the array
    for (int i = 0; i < 4; i++) {
      info[i] = players[i].toString();
    }

    // Initializes otherInfo with the turn number
    otherInfo = turnNum + " ";

    // Adds information about the cards in the deck to the last index
    for (int i = 0; i < deck.getSize(); i++) {
      otherInfo += deck.getDeck()[i].toString() + " ";
    }

    // Adds the information about the turn number and deck into the string array
    info[4] = otherInfo;

    // Creates a printwriter and sets it to null
    PrintWriter outputStream = null;

    try {

      // Creates the printwriter
      outputStream = new PrintWriter(new FileWriter("Save.txt"));

      // Writes the information to the file
      for (int i = 0; i < 5; i++) {
        outputStream.println(info[i]);
      }

      // Prints that the save was sucessful
      System.out.println("\nSave Successful");
    } catch (IOException e) {

      // Saves fails if there's an error
      System.out.println("Save Failed");
    } finally {

      // Closes the file
      if (outputStream != null) {
        outputStream.close();
      }
    }
  }



  /** Loads the save file
   */
  
  public void load() {

    // String variables to keep track of information contained in the save file
    String[] info = new String[0];
    String[] temp = new String[0];
    String[] splitLine = new String[0];
    String[] turnDeckInfo = new String[0];
    
    // Boolean to keep track of whether the information in the save file was tampered with
    loadFail = false;

    // Creates reader and sets it to null
    BufferedReader inputStream = null;

    try {

      // Creates a BufferedReader
      inputStream = new BufferedReader(new FileReader("Save.txt"));
      
      // Reads the information line by line and copies it into the info array
      for (int i = 0; i < 5; i++) {

        // Creates a temp array 1 length longer than the original info array
        temp = new String[info.length + 1];
        
        // Copies the information into the temporary array
        for (int j = 0; j < info.length; j++) {
          temp[j] = info[j];
        }
        
        // Copies the new read line to the temp array
        temp[temp.length - 1] = inputStream.readLine();

        // Copies the temporary array back into the original array
        info = temp;
      }
    } catch (IOException e) {

      // When an IOException ocurrs, the load fails
      loadFail = true;
    } finally {

      // Closes the file
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (IOException e) {
        }
      }
    }
    
    // Checks if each line is valid
    for (int i = 0; i < info.length; i++) {
      if (info[i] == null) {
        loadFail = true;
      }
    }

    // Variables to hold a player's information before creating that player
    int numCoins = 0;
    int rank = 0;
    numAmbassador = 0;
    numAssassin = 0;
    numCaptain = 0;
    numContessa = 0;
    numDuke = 0;
    String name = "";
    Card card1 = null;
    Card card2 = null;
    Card ogCard1 = null;
    Card ogCard2 = null;
    Card[] tempDeck = null;
    Player p;
    Player tempPlayers[] = new Player[4];
    Player tempAlive[];
    numAlivePlayers = 4;

    // Checks if the load has failed yet and if it hasn't, the information is copied into the players
    if (!loadFail) {

      // Splits up the turn number and information about the cards in the deck into a string array
      turnDeckInfo = info[4].split(" ");

      // The number of elements in the last line should always be 8: 7 cards and 1 turn number
      if (turnDeckInfo.length == 8) {

        // Converts the first index of the array (the turn number) into an integer and stores it if possible
        try {
          turnNum = Integer.parseInt(turnDeckInfo[0]);
        } catch (NumberFormatException e) {
          loadFail = true;
        }

        // Creates a temporary deck as a Card[]
        tempDeck = new Card[turnDeckInfo.length - 1];

        // Checks the remaining strings in the last line to see if they are cards or not
        for (int j = 1; j < turnDeckInfo.length; j++) {

          // Checks if the card is valid by comparing the card toCard returns with the actual string
          tempDeck[j - 1] = toCard(turnDeckInfo[j]);
          if (!(tempDeck[j - 1].toString().equals(turnDeckInfo[j]))) {
            
            // Load fails, exit loop
            loadFail = true;
            j = turnDeckInfo.length;
          }
        }
      } else {
        
        // If there aren't eight elements in the last line, the load fails
        loadFail = true;
      }

      // The first four lines contain information about the players
      for (int i = 0; i < 4; i++) {
        
        // Splits the information for each player up
        splitLine = info[i].split(", ");

        // Checks if there are 5 pieces of information in the line
        if (!(splitLine.length == 7)) {
          loadFail = true;
        }

        // Checks each index to see if they're valid types by trying to convert them (int, Card, Card, String, int)
        if (!loadFail) {
          try {
            numCoins = Integer.parseInt(splitLine[0]);
          } catch (NumberFormatException e) {
            loadFail = true;
          }
        }

        // Checks if card1 is a valid card
        if (!loadFail) {
          if (!((card1 = toCard(splitLine[1])).toString().equals(splitLine[1]))) {
            loadFail = true;
          }
        }

        // Checks if card2 is a valid card
        if (!loadFail) {
          if (!((card2 = toCard(splitLine[2])).toString().equals(splitLine[2]))) {
            loadFail = true;
          }
        }
        
        if (!loadFail) {

          // Creates ogCard1
          ogCard1 = toCard(splitLine[5]);

          // Checks if ogCard1 is a valid card
          if (!(ogCard1.toString().equals(splitLine[5]))) {
            loadFail = true;
          } else {

            // Checks to see if card1 and ogCard1 are different types of cards if card1 is not dead
            if (!((!card1.toString().equals("Dead") && card1.toString().equals(ogCard1.toString())) || card1.toString().equals("Dead"))) {
              loadFail = true;
            }
          }

          // Checks if card1 is counted twice : it is counted twice if card1 and ogcard1 are the same
          if (card1.toString().equals(ogCard1.toString())) {
            countDupes(card1);
          }
        }

        if (!loadFail) {

          // Creates ogCard2
          ogCard2 = toCard(splitLine[6]);

          // Checks if ogCard2 is a valid card
          if (!(ogCard2.toString().equals(splitLine[6]))) {
            loadFail = true;
          } else {

            // Checks to see if card1 and ogCard1 are different types of cards if card1 is not dead
            if (!((!card2.toString().equals("Dead") && card2.toString().equals(ogCard2.toString())) || card2.toString().equals("Dead"))) {
              loadFail = true;
            }
          }

          // Checks if card2 was counted twice : it is counted twice if card1 and ogcard1 are the same
          if (card2.toString().equals(ogCard2.toString())) {
            countDupes(card2);
          }
        }

        if (!loadFail) {

          // Creates the player's name
          name = splitLine[3];

          // Checks if the rank is a number
          try {
            rank = Integer.parseInt(splitLine[4]);
          } catch (NumberFormatException e) {
            loadFail = true;
          }
        }

        // Loads the data into a new player
        if (!loadFail) {
          
          // Creates a corresponding player based on their index in the array
          if (i == 0) {
            
            // Index 0 in the players array is the human player
            p = new HumanPlayer(card1, card2, name);
            tempPlayers[i] = p;

          } else if (i == 1) {

            // Index 1 in the players array is the passive ai
            p = new PassiveAI(card1, card2, name);
            tempPlayers[i] = p;

          } else if (i == 2) {

            // Index 2 in the players array is the aggressive ai
            p = new AggressiveAI(card1, card2, name);
            tempPlayers[i] = p;

          } else {
            
            // Index 3 in the players array is the wildcard ai
            p = new WildcardAI(card1, card2, name);
            tempPlayers[i] = p;
          }

          // Assigns all of the other information to the player
          tempPlayers[i].setOgCard1(ogCard1);
          tempPlayers[i].setOgCard2(ogCard2);
          tempPlayers[i].setRank(rank);
          tempPlayers[i].setNumCoins(numCoins);
          if (tempPlayers[i].getCard1().toString().equals("Dead") && tempPlayers[i].getCard2().toString().equals("Dead")) {
            tempPlayers[i].setIsAlive(false);
            numAlivePlayers--;
          }
        }

        // Exit loop if any information is incorrect
        if (loadFail) {
          i = 4;
        }
      }
    }
    // Checks if there are any players with the same names
    if (!loadFail) {
      for (int i = 0; i < tempPlayers.length; i++) {
        for (int j = i + 1; j < tempPlayers.length; j++) {

          // Checks to see if the player at the index has the same name as another player
          if (tempPlayers[i].getName().equals(tempPlayers[j].getName())) {

            // Exits the loops and sets loadFail to true
            loadFail = true;
            j = tempPlayers.length;
            i = tempPlayers.length;
          }
        }
      }
    }

    // Checks if there are any players with the same non-zero rank
    if (!loadFail) {
      for (int i = 0; i < tempPlayers.length; i++) {
        for (int j = i + 1; j < tempPlayers.length; j++) {

          // Checks to see if the player at the index has the same rank as another player
          if (tempPlayers[i].getRank() == tempPlayers[j].getRank() && tempPlayers[i].getRank() != 0) {

            // Exits the loops and sets loadFail to true
            loadFail = true;
            j = tempPlayers.length;
            i = tempPlayers.length;
          }
        }
      }
    }
    // Checks if there are 3 of each type of card
    if (numAmbassador == 3 && numAssassin == 3 && numCaptain == 3 && numContessa == 3 && numDuke == 3 && !loadFail) {

      // Copies the temporary array into the players array
      players = tempPlayers;

      // Sets actual deck as temporary deck
      deck.setDeck(tempDeck);

      // Updates alivePlayers array based on the alive players
      tempAlive = new Player[numAlivePlayers];
      int counter = 0;

      // Copies the alive players into the tempAlive array
      for (int i = 0; i < players.length; i++) {
        if (players[i].getIsAlive()) {
          tempAlive[counter] = players[i];
          counter++;
        }
      }

      // Copies the tempAlive array into the actual array of alive players
      alivePlayers = tempAlive;

    } else {
      loadFail = true;
    }

    // Prints whether or not the load was sucessful or not
    if (loadFail) {
      System.out.println("\nLoading was unsucessful. Please start a new game instead.\n\n");
    } else {
      System.out.println("\nLoading was sucessful\n\n");
    }
  }



  /** Reduces the counter of one of the types of cards by 1
   * @param card is the card who's card type counter is to be reduced
  */

  public void countDupes(Card card) {

    // Checks the card type of the card and subtracts the matching counter
    if (card.toString().equals("Ambassador")) {
      numAmbassador--;
    } else if (card.toString().equals("Assassin")) {
      numAssassin--;
    } else if (card.toString().equals("Captain")) {
      numCaptain--;
    } else if (card.toString().equals("Contessa")) {
      numContessa--;
    } else if (card.toString().equals("Duke")) {
      numDuke--;
    }
  }



  /** Takes a string type object and returns the corresponding card type
   * @param card is the string to be converted into a card
   * @return a card type based on the string
   */

  public Card toCard(String card) {
    
    // Returns a card based on the string parameter and increases the number of that type of card
    if (card.equals("Ambassador")) {
      numAmbassador++;
      return new Ambassador();
    }

    if (card.equals("Assassin")) {
      numAssassin++;
      return new Assassin();
    }

    if (card.equals("Captain")) {
      numCaptain++;
      return new Captain();
    }

    if (card.equals("Contessa")) {
      numContessa++;
      return new Contessa();
    }

    if (card.equals("Dead")) {
      return new Dead();
    }

    if (card.equals("Duke")) {
      numDuke++;
      return new Duke();
    }

    // Returns a Duke even if the string parameter was not a correct type of card
    return new Duke();
  }



  /** Prints the scoreboard and turn number after the game ends, and asks if the user wants to play again
   * @return if the user wants to play again or not
   */

  public Boolean endGame() {

    System.out.println("\nGAME OVER. Game ended on turn " + turnNum + "\n\nScoreboard:\n\n");

    // Sorts the players by rank
    for (int i = 0; i < 4; i++) {
      sort(players);
    }

    // Prints the scoreboard
    for (int i = 0; i < 4; i++) {
      System.out.println(players[i].getRank() + ". " + players[i].getName() + "\n");
    }

    // Asks the user if they want to play again
    System.out.print("\nDo you wish to play again? Enter yes or no: ");
    String playAgain = input.nextLine().toLowerCase();

    // Ensures the user is entering either yes or no
    while (!(playAgain.equals("yes") || playAgain.equals("no"))) {
      System.out.print("Please enter either yes or no: ");
      playAgain = input.nextLine().toLowerCase();
    }

    // Returns whether or not the player wants to play again
    if (playAgain.equals("yes")) {
      return true;
    }
    return false;
  }



  /** Sorts the array of players by rank by using insertion sort
   * @param players is the array of players to be sorted
   */
  
  public void sort(Player[] players) {

    // Declaration and initialization of variables
    int counter = 0;
    Player temp;

    // Checks each index, starting from the first one, and compares it to the previous value
    for (int i = 1; i < players.length; i++) {

      // Stores a value of the index in the wrong position
      temp = players[i];
      counter = i - 1;

      // Moves the elements in the array up until the temp is in the right position
      while (counter >= 0 && players[counter].getRank() > temp.getRank()) {
        players[counter + 1] = players[counter];
        counter--;
      }

      // Inserts the sorted value
      players[counter + 1] = temp;
    }

    // The player at index 0 is the winner of the game, and as a result does not die and be assigned a rank, so they must be assigned rank 1
    players[0].setRank(1);
  }



  /** Gets the array of players 
   * @return the array
   */

  public Player[] getPlayers() {
    return this.players;
  }

  /** Gets the array of alive players 
   * @return the array
   */

  public Player[] getAlivePlayers() {
    return this.alivePlayers;
  }

  /** Gets the number of alive players 
   * @return number of alive players
   */

  public int getNumAlivePlayers() {
    return numAlivePlayers;
  }

  /** Gets the deck
   * @return the deck
   */

  public Deck getDeck() {
    return this.deck;
  }

  /** Gets the index of the player whose turn is next
   * @return the index of the player
   */

  public int getNextPlayer() {
    return this.nextPlayer;
  }
}