/**
* A Contessa object that implements the Card interface
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

class Contessa implements Card {

  //Methods

  public void use(Player user, Game game, String check) {
    // Empty method because Contessa is never used
  }

  public void use(Player user, Game game, int check) {
    // Empty method because Contessa is never used
  }


  /** Returns a string representation of the Contessa card
   * @return the name of the card
   */
   
  @Override
  public String toString() {
    return "Contessa";
  }
}