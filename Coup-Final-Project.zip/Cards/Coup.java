/**
* A Coup object that implements the Card interface
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

import java.util.*;

class Coup implements Card {
  
  //Methods

  /** Allows human player to kill another player's card by paying 7 coins
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, String check) {

    // Creates scanner to read input
    Scanner input = new Scanner(System.in);

    // Checks if the user has enough coins to coup
    if (user.getNumCoins() >= 7) {

      // Prompts user to pick a target
      System.out.println("\nWho do you want to use Coup on? Enter the number next to the player you wish to use Coup on.");

      int target = 0;

      // Lists the other players (AI's)
      for (int i = 1; i < game.getNumAlivePlayers(); i++) {
        Player player = game.getAlivePlayers()[i];
        System.out.println("Player " + i + ": " + player.getInfo());
      }

      // Checks if user enters a valid number
      do {
        
        // Ensures that user enters a integer
        try { 
          //prompts the user for input
          System.out.print("Invalid. Enter a valid integer from 1-"+ (game.getNumAlivePlayers() - 1) + " : ");
          target = Integer.parseInt(input.nextLine());
        } catch (NumberFormatException ex) {
          
        }

      } while (!(target >= 1 && target <= game.getNumAlivePlayers()));
      
      // Prints the action being done
      System.out.println(user.getName() + " uses Coup on " + game.getAlivePlayers()[target].getName());

      // User pays 7 coins
      user.setNumCoins(user.getNumCoins() - 7);

      // Checks if target's card1 is dead to determine which card to coup
      if (game.getAlivePlayers()[target].getCard1().toString().equals("Dead")) {

        // Target's card1 is dead, so kills card2
        System.out.println(game.getAlivePlayers()[target].getName() + " loses the card " + game.getAlivePlayers()[target].getCard2().toString());
        game.getAlivePlayers()[target].setCard2(new Dead());
        
      } else {

        // Taget's card1 is alive, so kills card1
        System.out.println(game.getAlivePlayers()[target].getName() + " loses the card " + game.getAlivePlayers()[target].getCard1().toString());
        game.getAlivePlayers()[target].setCard1(new Dead());

      }
      
      // Prints the user's balance
      System.out.println("\n" + user.getName() + "\'s new balance: " + user.getNumCoins());

    } else {

      // Gets user to pick another action
      System.out.println("You don't have enough coins to use Coup.");
      user.pickAction(game).use(user, game, check);

    }
  }



  /** Allows AI to kill another player's card by paying 7 coins
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, int check) {

    // Declaration and initilization of variables
    Random rndm = new Random();
    Player[] targets = new Player[game.getNumAlivePlayers() - 1]; //
    int rand;
    int counter = 0;

    // Creates a list of possible targets (everyone except the user themself)
    for (int i = 0; i < game.getNumAlivePlayers(); i++) {

      // Checks if the player at the index has the same name as the user
      if (!(game.getAlivePlayers()[i].getName().equals(user.getName()))) {
        targets[counter] = game.getAlivePlayers()[i];
        counter++;
      }
    }

    // Picks a random target
    rand = rndm.nextInt(targets.length);

    // Prints the action being done
    System.out.println(user.getName() + " uses Coup on " + targets[rand].getName());

    // The player who uses coup pays 7 coins
    System.out.println(user.getName() + " pays 7 coins");
    user.setNumCoins(user.getNumCoins() - 7);

    // Determines which card to kill based on whether card1 is alive or dead
    if (targets[rand].getCard1().toString().equals("Dead")) {

      // Target's card1 is dead, so their card2 is killed
      System.out.println(targets[rand].getName() + " loses the card " + targets[rand].getCard2().toString());
      targets[rand].setCard2(new Dead());

    } else {

      // Target's card1 is alive, so their card1 is killed
      System.out.println(targets[rand].getName() + " loses the card " + targets[rand].getCard1().toString());
      targets[rand].setCard1(new Dead());

    }

    // Prints the user's balance after using coup
    System.out.println("\n" + user.getName() + "\'s new balance: " + user.getNumCoins());
  }


  
  /** Returns a string representation of the Coup card
   * @return the name of the card
   */

  @Override
  public String toString() {
    return "Coup";
  }
}