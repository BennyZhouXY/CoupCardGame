/**
* An Assassin object that implements the Card interface
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

import java.util.*;

class Assassin implements Card {
  
  
  
  //Methods
  
  /** Allows human player to kill another player's card by paying 3 coins
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */
   
  public void use(Player user, Game game, String check){

    // Checks if the user has enough coins to use Assassin
    if (user.getNumCoins() >= 3) {    

      // Declaration and initilization of variables
      Scanner input = new Scanner(System.in);
      int target = 0;
      int counter = 1;

      // Gets user to pick a target
      System.out.println("Who do you want to use Assassin on? Enter a number next to the player you wish to use Assassin on.");

      // Lists the players in a list that the user can choose. Index 0 is the human player, and the user cannot assassinated themself
      for (int i = 1; i < game.getNumAlivePlayers(); i++) {
        Player player = game.getAlivePlayers()[i];
        System.out.println("\nPlayer " + i + " : " + player.getInfo());
      }


      // Checks if input is valid (between 1 and num of alive players)
      do {
        // Ensures that user enters a integer
        try{ 
          // Prompts user for input.
          System.out.print("Enter a valid integer from 1-"+ (game.getNumAlivePlayers() - 1) + " : ");
          target = Integer.parseInt(input.nextLine());
          
         }catch (NumberFormatException ex) {
          
        }

      } while (!(target >= 1 && target <= game.getNumAlivePlayers()-1));

      // Prints the action being done
      System.out.println(user.getName() + " pays 3 coins and attempts to use Assassin on " + game.getAlivePlayers()[target].getName());

      // User pays 3 coins
      user.setNumCoins(user.getNumCoins() - 3);      
      System.out.println(user.getName()+ "'s new balance: " + user.getNumCoins());

      // Checks if the target wants to block
      if (game.getAlivePlayers()[target].block(new Assassin())) {
        
        // Prints that the target chooses to block
        System.out.println(game.getAlivePlayers()[target].getName() + " attempts to block " + user.getName() + "'s Assassin");

        // Checks if user wants to challenge the block
        if (user.challenge()) {

          // Prints that the user wants to challenge the block
          System.out.println(user.getName() + " challenges " + game.getAlivePlayers()[target].getName() + "'s block");

          // Checks to see if the blocker actually had the ability to block
          if (game.getAlivePlayers()[target].getCard1().toString().equals("Contessa") || game.getAlivePlayers()[target].getCard2().toString().equals("Contessa")) {

            // The user loses the challenge and one of their cards is killed
            if (user.getCard1().toString().equals("Dead")) {

              // User's card1 is dead, so their card2 is killed
              System.out.println(game.getAlivePlayers()[target].getName() + " can block. " + user.getName() + " has lost the challenge and loses their " + user.getCard2().toString());
              user.setCard2(new Dead());

            } else {

              // User's card1 is alive, so their card1 is killed
              System.out.println(game.getAlivePlayers()[target].getName() + " can block. " + user.getName() + " has lost the challenge and loses their " + user.getCard1().toString());
              user.setCard1(new Dead());

            }

            // Swaps out the blocker's revealed Contessa
            swapCard(game.getAlivePlayers()[target], new Contessa(), game);

          } else {

            // Checks if the target's card1 is already dead
            if (game.getAlivePlayers()[target].getCard1().toString().equals("Dead")) {

              // Target's card1 is dead, so their card2 is killed
              System.out.println(game.getAlivePlayers()[target].getName() + " can not block. " + game.getAlivePlayers()[target].getName() + " has lost the challenge and loses their " + game.getAlivePlayers()[target].getCard2().toString());

              // Kills the target's second card
              game.getAlivePlayers()[target].setCard2(new Dead());

            } else {

              // Both cards are alive, so both cards are killed
              System.out.println(game.getAlivePlayers()[target].getName() + " can not block. " + game.getAlivePlayers()[target].getName() + " has lost the challenge and loses their " + game.getAlivePlayers()[target].getCard1().toString() + " and " + game.getAlivePlayers()[target].getCard2().toString());

              // Kills both of the target's cards : 1 is killed from losing the challenge, and the other is killed from the Assassin
              game.getAlivePlayers()[target].setCard1(new Dead());
              game.getAlivePlayers()[target].setCard2(new Dead());

            }
          
            // User revealed their assassin, so swaps it out
            System.out.println(user.getName() + " swaps their Assassin with another card.");
            swapCard(user, new Assassin(), game);
          }
        } else {

          // Prints that the user chooses not to challenge the block
          System.out.println(user.getName() + " chooses not to challenge the block. Assassination fails.");
        }
      } else {
        
        // Prints that the target does not want to block
        System.out.println(game.getAlivePlayers()[target].getName() + " does not wish to block.");
        
        // Kills a card based on whether the target's card1 is dead or not
        if ((game.getAlivePlayers()[target]).getCard1().toString().equals("Dead")) {
          
          // Target's card1 is dead, so their card2 is killed
          System.out.println("Assassination succeeds, " + game.getAlivePlayers()[target].getName() + " loses their " + game.getAlivePlayers()[target].getCard2().toString());
          game.getAlivePlayers()[target].setCard2(new Dead());
        } else { 
          
          // Target's card1 is alive, so their card1 is killed
          System.out.println("Assassination succeeds, " + game.getAlivePlayers()[target].getName() + " loses their " + game.getAlivePlayers()[target].getCard1().toString());
          game.getAlivePlayers()[target].setCard1(new Dead());
        }

      }
    }
    //If user does not have enough coins to assassin, prompt user to pick action again 
    else 
    {
      System.out.println("You do not have enough coins to use Assassin. Please pick another action.");
      user.pickAction(game).use(user, game, check);
    }
  }

  /** Allows AI kill another player's card by paying 3 coins
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, int check) {

    // Declaration and initialization of variables
    Random rndm = new Random();
    Player[] targets = new Player[game.getNumAlivePlayers() - 1];
    int target = 0;
    int index = 0;

    // Ensures that the user is not able to target themself
    for (int i = 0; i < game.getNumAlivePlayers(); i++) {
      
      // Checks if the user does not have the same name as the player being checked
      if (!(game.getAlivePlayers()[i].getName().equals(user.getName()))) {

        targets[index] = game.getAlivePlayers()[i];
        index++;
      }
    }

    // AI picks a random target from the targets array
    target = rndm.nextInt(targets.length);

    // User pays 3 coins
    user.setNumCoins(user.getNumCoins() - 3);

    // Prints the action being done
    System.out.println(user.getName() + " attempts to use Assassin on " + targets[target].getName());

    // Checks if the target wants to block the assassin
    if (targets[target].block(new Assassin())) {
      
      System.out.println(targets[target].getName() + " attempts to block " + user.getName() + "'s Assassin");

      // Checks if the user wants to challenge the block
      if (user.challenge()) {

        System.out.println(user.getName() + " challenges " + targets[target].getName() + "'s block");

        // Checks to see if the blocker could actually block
        if (targets[target].getCard1().toString().equals("Contessa") || targets[target].getCard2().toString().equals("Contessa")) {

          // User loses the challenge and loses a card which is picked based on whether card1 is dead or not
          if (user.getCard1().toString().equals("Dead")) {

            // User's card1 is dead, so their card2 dies
            System.out.println(user.getName() + " has lost the challenge and loses their " + user.getCard2().toString());
            user.setCard2(new Dead());

          } else {

            // User's card1 is alive, so their card1 dies
            System.out.println(user.getName() + " has lost the challenge and loses their " + user.getCard1().toString());
            user.setCard1(new Dead());

          }
          
          // Blocker swaps their Contessa out because they revealed it
          swapCard(targets[target], new Contessa(), game);
          
        } else {

          // Blocker loses the challenge and loses their cards
          if (targets[target].getCard1().toString().equals("Dead")) {

            // Target's card1 is dead, so their card2 dies
            System.out.println(targets[target].getName() + " has lost the challenge and loses their " + targets[target].getCard2().toString());
            game.getAlivePlayers()[target].setCard2(new Dead());
          } else {

            // Both of the target's cards are alive, so both of their cards are killed
            System.out.println(game.getAlivePlayers()[target].getName() + " has lost the challenge and loses their " + targets[target].getCard1().toString() + " and " + targets[target].getCard2().toString());
            targets[target].setCard1(new Dead());
            targets[target].setCard2(new Dead());

          }

          // User reveals their Assassin, so they swap their Assassin out
          System.out.println(user.getName() + " swaps out their Assassin.");
          swapCard(user, new Assassin(), game);
          
        }
      } else {
        // User chooses not to challenge the block
        System.out.println(user.getName() + " decides not to challenge the block.");
      }
    } else { 
      // Target chooses not to block
      System.out.println(targets[target].getName() + " decides not to block.");
      
      // Kills one of the target's cards picked by whether their card1 is dead or not
      if (targets[target].getCard1().toString().equals("Dead")) {

        // Target's card1 was dead, so their card2 dies
        System.out.println("Assassination succeeds, " + targets[target].getName() + " loses their " + targets[target].getCard2().toString());
        game.getAlivePlayers()[target].setCard2(new Dead());

      } else { 

        // Target's card1 was alive, so their card1 dies
        System.out.println("Assassination succeeds, " + targets[target].getName() + " loses their " + targets[target].getCard1().toString());
        targets[target].setCard1(new Dead());

      }
    }
  }

  /** Allows winner of the challenge to swap the card they revealed with 1 card from the deck
   * @param user the player calling the method
   * @param card the card being swapped
   * @param game the game object the player was created in
   */

  public void swapCard(Player user, Card card, Game game) {

    // Adds the card back to the deck
    game.getDeck().addCard(card);

    // Gives the blocker a new card
    if (user.getCard1().toString().equals(card.toString())) {

      // Sets card1 of the blocker to another drawn card
      user.setCard1(game.getDeck().draw());
      user.setOgCard1(user.getCard1());

    } else {

      // Sets card2 of the blocker to another drawn card
      user.setCard2(game.getDeck().draw());
      user.setOgCard2(user.getCard2());
      
    }
  }

  /** Returns the card's name
   * @return the name
   */
   
  @Override
  public String toString() {
    return "Assassin";
  }
}