/**
* A Captain object that implements the Card interface
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.01
* @since   2019-01-08 
*/

import java.util.*;

class Captain implements Card {

  /** Allows human player to steal two coins from another player
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */



   //Methods
  
  public void use(Player user, Game game, String check) {

    // Initialize variables
    Scanner input = new Scanner(System.in);
    Player[] eligiblePlayers = new Player[0], alivePlayers;
    int targetNumber = -1;
    String challenge;
    Player target; 
    alivePlayers = game.getAlivePlayers(); 

    // Compiles all of the players the user can steal from into an array
    eligiblePlayers = findTargets(user, alivePlayers);

    // Checks if no alive players have 2+ coins
    if (eligiblePlayers.length == 0) {

      // Gets user to pick another action
      System.out.println("\nThere are no eligible players to steal from. Please pick another action.");
      user.pickAction(game).use(user, game, check);

    } else {

      // Lists the players the user can steal from
      System.out.println("\nAvailable Targets");
      for (int x = 0; x < eligiblePlayers.length; x++) {
        System.out.println("Player: " + Integer.toString(x + 1));
        System.out.println("Name: " + eligiblePlayers[x].getName()); 
        System.out.println("Coins: " + eligiblePlayers[x].getNumCoins() + "\n");
      }
    }

    // Checks if input is valid
    do {       
      // Ensures that user enters a integer  
      try{

        // Prompts Human Player for input
        System.out.print("Enter a valid integer from 1-" + eligiblePlayers.length + " : ");
        targetNumber = Integer.parseInt(input.nextLine());
      } catch (NumberFormatException ex) {
      
      }

    } while (!(targetNumber >= 1 && targetNumber <= eligiblePlayers.length));

    
    // Assigns target to the player the user targets
    target = eligiblePlayers[targetNumber - 1];
    
    // Prints the action being done
    System.out.println(user.getName() + " attempts to use Captain on " + target.getName());

    // Checks if target wants to block
    if (target.block(new Captain())) {

      // Prints that the target wants to block
      System.out.println(target.getName() + " attempts to block " + user.getName() + "'s Captain");
      
      //User is asked if they want to challenge the block. Returns a boolean. If challenge is true, checks to see who wins the challenge. If the user doesn't challenge, nothing happens.
      if (user.challenge()) {
        
        // Creates a string representation of card1 and card2
        String card1 = target.getCard1().toString();
        String card2 = target.getCard2().toString();
        
        // Prints that the user wants to challenge the blocker's block
        System.out.println(user.getName() + " challenges " + target.getName() + "'s block");

        // Checks if the blocker was bluffing
        if (((card1.equals("Captain") || card1.equals("Ambassador"))) || ((card2.equals("Captain") || card2.equals("Ambassador")))) { 
          
          // Prints who won the challenge (blocker)
          System.out.println(target.getName() + " can block. Therefore, " + user.getName() + " loses a card.");

          // User loses the challenge, so user loses a card
          makeDead(user.getCard1().toString(), user.getCard2().toString(), user);

          // Target wins the challenge, so swaps their revealed captain/ambassador out with another card in the deck
          if (card1.equals("Ambassador") || card2.equals("Ambassador")) {
            
            swapCard(target, new Ambassador(), game);
            System.out.println(target.getName() + " has swapped their revealed ambassador into the deck");

          } else {

            swapCard(target, new Captain(), game);
            System.out.println(target.getName() + " has swapped their revealed captain into the deck");

          }
          
        }
        else {

          // Prints that the blocker has won the challenge
          System.out.println("\n" + target.getName() + " can not block and loses the challenge, so they lose a card and 2 coins.");

          // Blocker loses a card
          makeDead(card1, card2, target);
          
          // User steals 2 coins from the target
          target.setNumCoins(target.getNumCoins() - 2);
          user.setNumCoins(user.getNumCoins() + 2);

          // Prints each of the player's new balance
          System.out.println(target.getName() +"'s new balance: " + target.getNumCoins());
          System.out.println(user.getName() +"'s new balance: " + user.getNumCoins());
          
          // Swaps the user's revealed captain with a new card
          swapCard(user, new Captain(), game);

          //Prints the player's new hand
          System.out.println("Card 1: " + user.getCard1().toString() + "\nCard 2: " + user.getCard2().toString());

        }

      } 
      else {

        // User does not choose to challenge
        System.out.println(user.getName() + " chooses not to challenge. Therefore, nothing happens");

      }

    } else {

      // Target does not choose to block      
      System.out.println("\n" + target.getName() + " chooses to not block. " + user.getName() + " steals sucessfully.");

      // User steals 2 coins from the target
      target.setNumCoins(target.getNumCoins() - 2);
      user.setNumCoins(user.getNumCoins() + 2);

      // Prints each of the player's new balance
      System.out.println("\n" + target.getName() +"'s new balance: " + target.getNumCoins());
      System.out.println(user.getName() +"'s new balance: " + user.getNumCoins());
    }
  }



  /** Allows AI player to steal 2 coins from another player
   * @param user is the user performing the action
   * @param game is the game the user is a part of
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, int check) {

    // Declaration and initialization of variables
    Player[] eligiblePlayers = new Player[0];
    Player[] alivePlayers;
    Player target;
    Random rndm = new Random();
    alivePlayers = game.getAlivePlayers();
    
    // Compiles all of the players the user can steal from into an array
    eligiblePlayers = findTargets(user, alivePlayers);

    // Checks if there are any eligible players to steal from. User picks another action if there are no targets
    if (eligiblePlayers.length == 0) { 
      user.pickAction(game).use(user, game, check);
    } else {

      //AI picks a target with at random
      target = eligiblePlayers[rndm.nextInt(eligiblePlayers.length)];
      System.out.println(user.getName() + " attempts to use Captain on " + target.getName());

      // Checks if the target wants to block
      if (target.block(new Captain())) {

        // Prints the action being done
        System.out.println(target.getName() + " attempts to block " + user.getName() + "'s Captain");

        // Checks if the user wants to challenge the target's block
        if (user.challenge()) {

          // Prints that the challenge is being done
          System.out.println(user.getName() + " challenges " + target.getName() + "'s block");

          // Creates string representations of card1 and card2
          String card1 = target.getCard1().toString();
          String card2 = target.getCard2().toString();

          // Checks to see if blocker can actually block
          if (((card1.equals("Captain") || card1.equals("Ambassador"))) || ((card2.equals("Captain") || card2.equals("Ambassador")))) {

            // Prints that the blocker wins the challenge
            System.out.println("\n" + target.getName() + " can block and loses a card.\n");

            // User loses a card because the lost the challenge
            makeDead(user.getCard1().toString(), user.getCard2().toString(), user);

            // Target wins the challenge, so swaps their revealed captain/ambassador out
            if (target.getCard1().toString().equals("Ambassador") || target.getCard2().toString().equals("Ambassador")) {
              swapCard(target, new Ambassador(), game);
            } else {
              swapCard(target, new Captain(), game);
            }
          }
          // The target can't block so they lose a card and 2 coins
          else {
            
            // Prints that the blocker loses the challenge
            System.out.println("\n" + target.getName() + " cannot block, so they lose a card and 2 coins.");

            // Blocker loses a card
            makeDead(card1, card2, target);

            // The user steals 2 coins from the target
            target.setNumCoins(target.getNumCoins() - 2);
            user.setNumCoins(user.getNumCoins() + 2);

            // Prints the new number of coins each player has
            System.out.println(target.getName() + "'s new balance: " + target.getNumCoins());
            System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());

            // Swaps the user's revealed captain with a new card
            swapCard(user, new Captain(), game);
          }

        } else {

          // Prints tswaps the Captain card with another in the deckha;t the user doesn't want to challenge the block
          System.out.println("\n" + user.getName() + " chooses not to challenge.");
        }

      } else {

        // Target doesn't want to block
        System.out.println(target.getName() + " chooses to not block the Captain. " + user.getName() + "\'s steal was sucessful.");

        // User steals
        target.setNumCoins(target.getNumCoins() - 2);
        user.setNumCoins(user.getNumCoins() + 2);

        // Prints each of the player's new balance
        System.out.println(target.getName() + "'s new balance: " + target.getNumCoins());
        System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());
      }
    }
  }



  /** Allows winner of the challenge to swap the card they revealed with 1 card from the deck
   * @param user the player calling the method
   * @param card the card being swapped
   * @param game the game object the player was created in
   */
   
  public void swapCard(Player user, Card card, Game game) {

    // Adds the card back to the deck
    game.getDeck().addCard(card);

    // Gives the blocker a new card, checks to see if card1 is the same type of card and the card to be swapped
    if (user.getCard1().toString().equals(card.toString())) {

      // Sets card1 of the blocker to another drawn card
      user.setCard1(game.getDeck().draw());
      user.setOgCard1(user.getCard1());
      
    } else {

      // Sets card2 of the blocker to another drawn card
      user.setCard2(game.getDeck().draw());
      user.setOgCard2(user.getCard2());
    }
  }


  
  /** Finds all of the targetable players
   * @param user is the user of the card
   * @param alivePlayers is the array of alive players
   * @return the list of targetable players
   */
  
  public Player[] findTargets(Player user, Player[] alivePlayers) {

    // Declaration and initilization of variables
    Player[] eligiblePlayers = new Player[0];
    Player player;
    Player[] temp;

    for (int i = 0; i < alivePlayers.length; i++) {

      // Keeps track of the player at the specified index
      player = alivePlayers[i];
      
      // Checks each player if the user can steal from them
      if ((player.getNumCoins() >= 2) && (!(player.getName().equals(user.getName())))) {

        // Creates a temp array 1 length longer
        temp = new Player[eligiblePlayers.length + 1];

        // Copies the original array into the temp array
        for (int j = 0; j < eligiblePlayers.length; j++) {
          temp[j] = eligiblePlayers[j];
        }

        // Copies the player into the end of the temp array
        temp[temp.length - 1] = player;

        // Copies the temp array back into the actual array
        eligiblePlayers = temp;
      }
    }
    
    // Returns the list of targets
    return eligiblePlayers;
  }



  /** Kills one of a player's cards, based on which of their cards are alive
   * @param card1 is the string name of the first card
   * @param card2 is the string name of the second card
   * @param person is the player who's card is to be set to dead
   */

  public void makeDead(String card1, String card2, Player person) {

    // Checks if card1 is still alive
    if (!(card1.equals("Dead"))) {

      // Kills card1
      System.out.println(person.getName() + " loses the card, " + person.getCard1().toString());
      person.setCard1(new Dead());
    } 
    else {

      // card1 is dead, so kills card2
      System.out.println(person.getName() + " loses the card, " + person.getCard2().toString());
      person.setCard2(new Dead());
    }
  }



  /** Return the card's name
   * @return the name
  */
  
  @Override
  public String toString() {
    return "Captain";
  }
}