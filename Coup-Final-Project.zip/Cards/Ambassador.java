/**
* An Ambassador object that implements the Card interface
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

import java.util.*;

class Ambassador implements Card {

  //Declare random object
  Random numGen = new Random();

  

  //Methods

  /** Allows human player to switch two cards or one card from the deck depending on how many cards they have are alive
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, String check) {

    // Declarization and initialization of variables
    Scanner input = new Scanner(System.in);
    Card [] eligibleCards = new Card[2];
    eligibleCards[0] = game.getDeck().draw();
    eligibleCards[1] = game.getDeck().draw();
    int userChoice1 = 0;
    int userChoice2 = 0;

    // Adds the users first card to the eligibleCards array if it is alive
    if (!((user.getCard1()).toString().equals("Dead"))) { 
      eligibleCards=(addCard(user.getCard1(), eligibleCards));
    }

    // Adds the users second card to the eligibleCards array if it is alive
    if ((!user.getCard2().toString().equals("Dead"))) {
      eligibleCards=(addCard(user.getCard2(), eligibleCards));
    }

    // Displays the cards that the user can choose to keep
    for (int i=0; i<eligibleCards.length; i++){
      System.out.println("\nCard "+ (i+1) + ": "+ eligibleCards[i].toString());
    }

    // Checks if input is valid
    do {    

      // Ensures that user enters a integer
      try{ 
        // Prompts Human Player for input
        System.out.print("\nWhat is the first card you would like to keep? (Please enter an integer 1-" + eligibleCards.length + ") : ");
        userChoice1 = Integer.parseInt(input.nextLine());
      }catch (NumberFormatException ex) {
      
      }

    } while (!(userChoice1 >= 1 && userChoice1 <= eligibleCards.length)); //Check for valid input (integer from 1-number of eligible cards)


    // If there are four cards in the eligibleCard array that means the user has 2 cards alive. This allows them to make a second choice
    if (4 == eligibleCards.length) {

      // Checks for valid input. Must be an integer, within valid choices and can't be same card
      do {
        // Ensures that the user enters an integer
        try{ 
          // Prompts user to determines the second card that the user wants to keep
          System.out.println("What is the second card you would like to keep? (Please enter an integer 1-" + eligibleCards.length + ") : ");
          userChoice2 = Integer.parseInt(input.nextLine());
          } catch (NumberFormatException ex) {

          }

        // Prints an error message when the user tries to pick the same card twice
        if (userChoice2 == userChoice1) {
          System.out.println("You cannot pick the same card twice.");
        }

      } while ((!(userChoice2 >= 1 && userChoice2 <= eligibleCards.length)) || (userChoice2 == userChoice1));
    }
    
    // If users first card is dead, switches out his second card
    if ((user.getCard1().toString().equals("Dead"))) { 

      // Sets user's card2 as the card they picked
      user.setCard2(eligibleCards[userChoice1 - 1]);
      user.setOgCard2(user.getCard2());
      
      // Removes the selected card from the eligibleCards array
      eligibleCards = removeCard((userChoice1 - 1), eligibleCards);
      System.out.println("Card 2 swapped to: " + user.getCard2().toString());
      
    } else if (user.getCard2().toString().equals("Dead")) {

      // If users second card is dead switches out his first card
      user.setCard1(eligibleCards[userChoice1-1]);
      user.setOgCard1(user.getCard1());

      // Removes the selected card from the eligibleCards array
      eligibleCards = removeCard((userChoice1 - 1), eligibleCards);
      System.out.println("Card 1 swapped to: " + user.getCard1().toString());

    } else {

      // Both cards are alive, switches out 2 cards

      // Swaps first card
      user.setCard1(eligibleCards[userChoice1-1]);
      System.out.println("Card 1 swapped to: " + user.getCard1().toString());
      user.setOgCard1(user.getCard1());

      // Swaps card 2
      user.setCard2(eligibleCards[userChoice2-1]);
      System.out.println("Card 2 swapped to: " + user.getCard2().toString());
      user.setOgCard2(user.getCard2());

      // Removes card1 from the eligibleCards array
      eligibleCards = removeCard((userChoice1 - 1), eligibleCards);

      // Checks if removing card1 will change the index of card2 (card2 comes after card1 in the array)
      if (userChoice2 > userChoice1){

        // Corrects the index of the user's second choice
        userChoice2--;
      }

      // Removes card2 from the eligibleCards array
      eligibleCards = removeCard((userChoice2 - 1), eligibleCards);  
    }
    
    //Sends the cards the user did not want back to the deck

    System.out.println(eligibleCards[0] + " sent back to deck");
    game.getDeck().addCard(eligibleCards[0]);

    System.out.println(eligibleCards[1] + " sent back to deck");
    game.getDeck().addCard(eligibleCards[1]);
  }

  /** Allows AI to switch two cards with the deck
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, int check){

    // Creates the eligibleCards array and adds two cards to it
    Card [] eligibleCards = new Card[2];
    eligibleCards[0] = game.getDeck().draw();
    eligibleCards[1] = game.getDeck().draw();
    
    //Adds the users first card to the eligibleCards array if it is alive
    if (!(user.getCard1().toString().equals("Dead"))){
      eligibleCards = addCard(user.getCard1(), eligibleCards);
    }

    //Adds the users second card to the eligibleCards array if it is alive
    if ((!user.getCard2().toString().equals("Dead"))) { 
      eligibleCards = addCard(user.getCard2(), eligibleCards);
    }
    
    //Checks to see how many cards are alive and switches accordingly
    if ((!user.getCard1().toString().equals("Dead")) && (!user.getCard2().toString().equals("Dead"))){ 

      // Both cards are alive, so both cards are changed

      // Swaps card 1
      int num = numGen.nextInt(eligibleCards.length);
      user.setCard1(eligibleCards[num]);
      user.setOgCard1(user.getCard1());
      System.out.println(user.getName() + " swaps card 1");

      // Removes card 1 from the eligibleCards array
      eligibleCards = removeCard(num, eligibleCards);
      
      // Swaps card 2
      num = numGen.nextInt(eligibleCards.length);
      user.setCard2(eligibleCards[num]);
      user.setOgCard2(user.getCard2());
      System.out.println(user.getName() + " swaps card 2");

      // Removes card 2 from the eligibleCards array
      eligibleCards = removeCard(num, eligibleCards);
  
    } else if (user.getCard1().toString().equals("Dead")){
      // Only card 1 is alive

      // Swaps card 1
      int num = numGen.nextInt(eligibleCards.length);
      user.setCard1(eligibleCards[num]);
      user.setOgCard1(user.getCard1());
      System.out.println(user.getName() + " swaps card 1");

      // Removes card 1 from the eligibleCards array
      eligibleCards = removeCard(num, eligibleCards);

    } else {

      // Only card 2 is alive

      // Swaps card 2
      int num = numGen.nextInt(eligibleCards.length);
      user.setCard2(eligibleCards[num]);
      user.setOgCard2(user.getCard2());
      System.out.println(user.getName() + " swaps card 2");

      // Removes the card from the eligibleCards array
      eligibleCards = removeCard(num, eligibleCards);
    }
    
    // Sends back the cards the user didn't want back to the deck
    game.getDeck().addCard(eligibleCards[0]);
    game.getDeck().addCard(eligibleCards[1]);
  }

  /** Returns the card's name
   * @return the name
   */

  @Override
  public String toString() {
    return "Ambassador";
  }

  /** Adds a card to the top of the specified card array and returns the array
   * @return the array
   * @param card the card to be added
   * @param cardArray the array to add a card to
   */

  public Card[] addCard(Card card, Card[] cardArray){

    // Creates a new array 1 length longer
    Card[] tempCards = new Card[cardArray.length+1];
    
    // Copies the original array into the temporary array
    for (int i=0; i<cardArray.length; i++){
      tempCards[i]=cardArray[i];
    }

    // Adds the card to the end of the array
    tempCards[cardArray.length]=card;

    // Copies the temporary array back into the original array
    cardArray=tempCards;

    // Returns the array of cards
    return cardArray;
  }

  

  /** Removes a card from the specified card array and return the array
   * @return the array
   * @param index the index of the card to be removed
   * @param cardArray the array the card is to be removed from
   */

  public Card[] removeCard(int index, Card[] cardArray){

    // Creates a temp array 1 length shorter
    Card[] temp = new Card[cardArray.length - 1];

    // Copies all of the cards into the temp array, excluding the undesired card
    for (int i = 0; i < cardArray.length; i++) {

      // Copies the card at the selected index into the temp array if it is not the card to be removed
      if (i > index) {
        temp[i - 1] = cardArray[i];
      } else if (!(i == index)) {
        temp[i] = cardArray[i];
      }
    }

    // Copies the temporary array back into the original array
    cardArray = temp;

    // Returns the card array
    return cardArray;
  }
}