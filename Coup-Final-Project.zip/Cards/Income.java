/**
* An Income object that implements the Card interface
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

class Income implements Card {

  //Methods

  /** Allows human player to gain 1 coin
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, String check) {

    // Prints action being done
    System.out.println(user.getName() + " uses income, gaining 1 coin");

    // Increases their coins by 1
    user.setNumCoins(user.getNumCoins() + 1);

    // Prints the user's new balance
    System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());
  }



  /** Allows AI to gain 1 coin
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, int check) {

    // Prints action being done
    System.out.println(user.getName() + " uses income, gaining 1 coin");

    // Increases their coins by 1
    user.setNumCoins(user.getNumCoins() + 1);

    // Prints the user's new balance
    System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());
  }

  

  /** Returns a string representation of the Income card
   * @return the name of the card
   */

  @Override
  public String toString() {
    return "Income";
  }

}