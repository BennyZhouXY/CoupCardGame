/**
* A ForeignAid object that implements the Card interface
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

class ForeignAid implements Card {
  
  //Methods

  /** Allows human player to gain 2 coins
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, String check) {

    // Prints action being done
    System.out.println(user.getName() + " attempts to use foreign aid");

    // Asks each player 1 by 1 if they want to block until a sucessful block/challenge resolves
    int counter = 0;
    Boolean resolved = false;

    while (counter < game.getNumAlivePlayers() && !resolved) {

      // Checks to see if the user is not asking themselves if they want to block
      if (!(user.getName().equals(game.getAlivePlayers()[counter].getName()))) {

        // Checks if the specified player wants to block the action
        if (game.getAlivePlayers()[counter].block(new ForeignAid())) { 

          // Prints that someone wants to block
          System.out.println(game.getAlivePlayers()[counter].getName() + " attempts to block " + user.getName() + "'s foreign aid");

          // Checks if the user wants to challenge the block
          if (user.challenge()) { 

            // Prints that the user wants to challenge the block
            System.out.println("\n" + user.getName() + " attempts to challenge " + game.getAlivePlayers()[counter].getName() + "\'s block.");

            // Checks if the blocker can actually block 
            if (game.getAlivePlayers()[counter].getCard1().toString().equals("Duke") || game.getAlivePlayers()[counter].getCard2().toString().equals("Duke")) {

              // Blocker is not bluffing, so checks if the user's card1 is dead
              if (user.getCard1().toString().equals("Dead")) {

                // User's card1 is dead, so their card2 dies
                System.out.println(user.getName() + " has lost the challenge and loses their " + user.getCard2().toString());
                user.setCard2(new Dead());

              } else {

                // User's card1 is alive, so their card1 dies
                System.out.println(user.getName() + " has lost the challenge and loses their " + user.getCard1().toString());
                user.setCard1(new Dead());
              }

              // Blocker wins the challenge, so their Duke is swapped out
              System.out.println(game.getAlivePlayers()[counter].getName() + " wins the challenge, so their Duke is swapped with a card in the deck");
              game.getDeck().addCard(new Duke());

              

              // Checks which of the cards the blocker had was a Duke, and swaps it out
              if (game.getAlivePlayers()[counter].getCard1().toString().equals("Duke")) {
                game.getAlivePlayers()[counter].setCard1(game.getDeck().draw());
                game.getAlivePlayers()[counter].setOgCard1(game.getAlivePlayers()[counter].getCard1());
              } else {
                game.getAlivePlayers()[counter].setCard2(game.getDeck().draw());
                game.getAlivePlayers()[counter].setOgCard2(game.getAlivePlayers()[counter].getCard2());
              }

            } else {

              // Blocker was bluffing, so they lose a card
              if (game.getAlivePlayers()[counter].getCard1().toString().equals("dead")) {

                // Blocker's card1 was dead, so they lose their card2
                System.out.println(game.getAlivePlayers()[counter].getName() + " has lost the challenge and loses their " + game.getAlivePlayers()[counter].getCard2().toString());
                game.getAlivePlayers()[counter].setCard2(new Dead());

              } else {

                // Blocker's card1 was alive, so they lose their card1
                System.out.println(game.getAlivePlayers()[counter].getName() + " has lost the challenge and loses their " + game.getAlivePlayers()[counter].getCard1().toString());
                game.getAlivePlayers()[counter].setCard1(new Dead());
              }

              // User gains 2 coins because their foreign aid suceeds
              System.out.println("Foreign aid succeeds, " + user.getName() + " gains 2 coins");
              user.setNumCoins(user.getNumCoins() + 2);
              System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());
            }
          } else {
            System.out.println(user.getName() + " decides not to challenge. Foreign aid fails.");
          }

          resolved = true;
        }
      }
      
      counter++;
    }
    
    // Checks to see if a block has been resolved. If a block has not been resolved yet, nobody has tried to block so the user gains two coins
    if (!resolved) {
      
      // User gains two coins
      System.out.println("Nobody chooses to block.");
      System.out.println("Foreign aid succeeds, " + user.getName() + " gains 2 coins");
      user.setNumCoins(user.getNumCoins() + 2);
      System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());
    }
  }



  /** Allows AI to gain 2 coins
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, int check) {

    // Prints action being done
    System.out.println(user.getName() + " attempts to use foreign aid.");

    // Asks each player 1 by 1 if they want to block until a sucessful block/challenge resolves
    int counter = 0;
    Boolean resolved = false;

    while (counter < game.getNumAlivePlayers() && !resolved) {

      // Checks to see if the player is not asking themself if they want to block
      if (!(user.getName().equals(game.getAlivePlayers()[counter].getName()))) {

        // Checks if the player wants to block the foreign aid
        if (game.getAlivePlayers()[counter].block(new ForeignAid())) {

          // Prints that someone wants to block
         System.out.println(game.getAlivePlayers()[counter].getName() + " attempts to block " + user.getName() + "'s foreign aid");

          // Checks if the user wants to challenge the block
          if (user.challenge()) {

            // Prints that the user is challenging the block
            System.out.println("\n" + user.getName() + " attempts to challenge " + game.getAlivePlayers()[counter].getName() + "\'s block.");

            // Checks if the blocker actually has the ability to block
            if (game.getAlivePlayers()[counter].getCard1().toString().equals("Duke") || game.getAlivePlayers()[counter].getCard2().toString().equals("Duke")) {

              // Blocker is not bluffing, so checks if the user's card1 is dead
              if (user.getCard1().toString().equals("Dead")) {

                // User's card1 was dead, so they lose their card2
                System.out.println("\n" + user.getName() + " has lost the challenge and loses their " + user.getCard2().toString());
                user.setCard2(new Dead());
              } else {

                // User's card1 was alive, so they lose their card1
                System.out.println("\n" + user.getName() + " has lost the challenge and loses their " + user.getCard1().toString());
                user.setCard1(new Dead());
              }

              // Blocker wins the challenge, so their Duke is swapped out
              System.out.println(game.getAlivePlayers()[counter].getName() + " wins the challenge, so their Duke is swapped with a card in the deck");
              game.getDeck().addCard(new Duke());

              // Checks which of the cards the blocker had was a Duke, and swaps it out
              if (game.getAlivePlayers()[counter].getCard1().toString().equals("Duke")) {
                game.getAlivePlayers()[counter].setCard1(game.getDeck().draw());
                game.getAlivePlayers()[counter].setOgCard1(game.getAlivePlayers()[counter].getCard1());
              } else {
                game.getAlivePlayers()[counter].setCard2(game.getDeck().draw());
                game.getAlivePlayers()[counter].setOgCard2(game.getAlivePlayers()[counter].getCard2());
              }

            } else {

              // Blocker was lying, so blocker loses a card. Checks if card1 is dead
              if (game.getAlivePlayers()[counter].getCard1().toString().equals("dead")) {

                // Blocker's card1 is dead, so blocker loses their card2
                System.out.println(game.getAlivePlayers()[counter].getName() + " has lost the challenge and loses their " + game.getAlivePlayers()[counter].getCard2().toString());
                game.getAlivePlayers()[counter].setCard2(new Dead());
              } else {

                // Blocker's card1 is alive, so blocker loses their card1
                System.out.println(game.getAlivePlayers()[counter].getName() + " has lost the challenge and loses their " + game.getAlivePlayers()[counter].getCard1().toString());
                game.getAlivePlayers()[counter].setCard1(new Dead());
              }

              // User's foreign aid succeeds because blocker was bluffing
              System.out.println("Foreign aid succeeds, " + user.getName() + " gains 2 coins");
              user.setNumCoins(user.getNumCoins() + 2);
              System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());
            }
          } else {

            // Prints that the user does not want to challenge the block
            System.out.println(game.getAlivePlayers()[counter].getName() + "\'s block was sucessful. Foreign aid fails.");
          }

          // The block is resolved
          resolved = true;
        }
      }

      // Increases the index of the next person to be checked
      counter++;
    }

    // Checks to see if a block has been resolved. If a block has not been resolved yet, nobody has tried to block so the user gains two coins
    if (!resolved) {
      
      // User gains two coins
      System.out.println("Nobody chooses to block.");
      System.out.println("Foreign aid succeeds, " + user.getName() + " gains 2 coins");
      user.setNumCoins(user.getNumCoins() + 2);
      System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());
    }
  }

  

  /** Returns a string representation of the Foreign Aid card
   * @return the name of the card
   */

  @Override
  public String toString() {
    return "Foreign Aid";
  }

}