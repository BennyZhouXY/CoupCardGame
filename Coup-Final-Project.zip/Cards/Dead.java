/**
* A Dead card object that implements the Card interface
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

class Dead implements Card {
  
  //Methods

  public void use(Player user, Game game, String check) {
    // Empty method because dead cards are never used
  }

  public void use(Player user, Game game, int check) {
    // Empty method because dead cards are never used
  }


  /** Returns a string representation of the Dead card
   * @return the name of the card
   */

  @Override
  public String toString() {
    return "Dead";
  }
}