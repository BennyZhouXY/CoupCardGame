/**
* A Duke object that implements the Card interface
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

class Duke implements Card {
  
  //Methods

  /** Allows human player to gain 3 coins
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, String check) {

    // Prints that the user attempts to use Duke
    System.out.println("\n" + user.getName() + " attempts to use Duke");

    // Asks each player if they want to block or not
    int counter = 0;
    Boolean resolved = false;

    while (counter < game.getNumAlivePlayers() && !resolved) {

      // Checks to make sure the user is not asking themself if they want to block themself
      if (!(user.getName().equals(game.getAlivePlayers()[counter].getName()))) {

       // Checks if the specified player wants to block the action
        if (game.getAlivePlayers()[counter].block(new Duke())) {

          // Prints who wants to block
          System.out.println("\n" + game.getAlivePlayers()[counter].getName() + " attempts to block " + user.getName() + "\'s Duke.");

          // Checks if the user wants to challenge the blocker
          if (user.challenge()) {

            // Prints that the user wants to challenge the block
            System.out.println("\n" + user.getName() + " attempts to challenge " + game.getAlivePlayers()[counter].getName() + "\'s block.");

            // Checks if the player who blocked actually has the ability to block Duke
            if (game.getAlivePlayers()[counter].getCard1().toString().equals("Contessa") || game.getAlivePlayers()[counter].getCard2().toString().equals("Contessa")) {

              // Blocker is not bluffing, so the user loses the challenge and a card based on whether card1 is dead or not
              if (user.getCard1().toString().equals("Dead")) {

                // User's card1 is dead, so user's card2 is killed
                System.out.println(user.getName() + " has lost the challenge and loses their " + user.getCard2().toString());
                user.setCard2(new Dead());

              } else {

                // User's card1 is alive, sp user's card1 is killed
                System.out.println(user.getName() + " has lost the challenge and loses their " + user.getCard1().toString());
                user.setCard1(new Dead());

              }

              // Blocker wins the challenge, so their Contessa is swapped out
              System.out.println(game.getAlivePlayers()[counter].getName() + " wins the challenge, so their Contessa is swapped with a card in the deck");
              game.getDeck().addCard(new Contessa());

              // Checks which of the cards the blocker had was a Contessa, and swaps it out
              if (game.getAlivePlayers()[counter].getCard1().toString().equals("Contessa")) {
                game.getAlivePlayers()[counter].setCard1(game.getDeck().draw());
                game.getAlivePlayers()[counter].setOgCard1(game.getAlivePlayers()[counter].getCard1());
              } else {
                game.getAlivePlayers()[counter].setCard2(game.getDeck().draw());
                game.getAlivePlayers()[counter].setOgCard2(game.getAlivePlayers()[counter].getCard2());
              }

            } else {

              // Blocker was bluffing, so blocker loses a card based on whether their card1 is dead or not
              if (game.getAlivePlayers()[counter].getCard1().toString().equals("Dead")) {

                // Blocker's card1 is dead, so blocker's card2 is killed
                System.out.println(game.getAlivePlayers()[counter].getName() + " has lost the challenge and loses their " + game.getAlivePlayers()[counter].getCard2().toString());
                game.getAlivePlayers()[counter].setCard2(new Dead());

              } else {

                // Blocker's card1 is alive, so blocker's card1 is killed
                System.out.println(game.getAlivePlayers()[counter].getName() + " has lost the challenge and loses their " + game.getAlivePlayers()[counter].getCard1().toString());
                game.getAlivePlayers()[counter].setCard1(new Dead());

              }

              // User's Duke is sucessful and they gain 3 coins
              System.out.println(user.getName() + "\'s Duke was sucessful. They gain 3 coins.");
              user.setNumCoins(user.getNumCoins() + 3);
              System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());

              // User wins the challenge, so their revealed Duke is swapped out
              System.out.println(user.getName() + " wins the challenge, so their Duke is swapped with a card in the deck\n");
              game.getDeck().addCard(new Duke());

              // Checks which of the cards the user had was the duke and replaces it with a new card
              if (user.getCard1().toString().equals("Duke")) {
                user.setCard1(game.getDeck().draw());
                user.setOgCard1(user.getCard1());
              } else {
                user.setCard2(game.getDeck().draw());
                user.setOgCard2(user.getCard2());
              }
            }
          } else {
            // User chooses not to challenge
            System.out.println("\n" + user.getName() + " does not choose to challenge " + game.getAlivePlayers()[counter].getName() + "\'s block. \nDuke fails.");
          }

          // A block has ocurred, so the user's Duke is resolved
          resolved = true;
        }
      }

      // Increases the index to ask the next player if they want to block
      counter++;
    }

    // Checks if nobody blocked
    if (!resolved) {

      // User gains 3 coins
      System.out.println("\nNobody chooses to block.");
      user.setNumCoins(user.getNumCoins() + 3);
      System.out.println("\n" + user.getName() + " new balance: " + user.getNumCoins());
    }
  }

  /** Allows AI to gain 3 coins
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, int check) {

    // Prints action being done
    System.out.println(user.getName() + " attempts to use Duke");
    
    // Asks each player 1 by 1 if they want to block
    int counter = 0;
    Boolean resolved = false;

    while (counter < game.getNumAlivePlayers() && !resolved) {

      // Checks to make sure the user is not asking themself if they want to block themself
      if (!(user.getName().equals(game.getAlivePlayers()[counter].getName()))) {

        // Checks if the player wants to block the action
        if (game.getAlivePlayers()[counter].block(new Duke())) {

          // Prints who wants to block
          System.out.println("\n" + game.getAlivePlayers()[counter].getName() + " attempts to block " + user.getName() + "\'s Duke.");

          // Checks if the user wants to challenge the block
          if (user.challenge()) {

            // Prints that the user wants to challenge the block
            System.out.println("\n" + user.getName() + " attempts to challenge " + game.getAlivePlayers()[counter].getName() + "\'s block.");

            // Checks if the blocker actually has the ability to block
            if (game.getAlivePlayers()[counter].getCard1().toString().equals("Contessa") || game.getAlivePlayers()[counter].getCard2().toString().equals("Contessa")) {

              // Blocker wins the challenge, so the user loses a card
              if (user.getCard1().toString().equals("Dead")) {

                // User's card1 is dead, so they lose their card2
                System.out.println(user.getName() + " has lost the challenge and loses their " + user.getCard2().toString());
                user.setCard2(new Dead());

              } else {

                // User's card1 is alive, so they lose their card1
                System.out.println(user.getName() + " has lost the challenge and loses their " + user.getCard1().toString());
                user.setCard1(new Dead());

              }

              // Blocker wins the challenge, so their Contessa is swapped out
              System.out.println(game.getAlivePlayers()[counter].getName() + " wins the challenge, so their Contessa is swapped with a card in the deck");
              game.getDeck().addCard(new Contessa());

              // Checks which of the cards the blocker had was a Contessa, and swaps it out
              if (game.getAlivePlayers()[counter].getCard1().toString().equals("Contessa")) {
                game.getAlivePlayers()[counter].setCard1(game.getDeck().draw());
                game.getAlivePlayers()[counter].setOgCard1(game.getAlivePlayers()[counter].getCard1());
              } else {
                game.getAlivePlayers()[counter].setCard2(game.getDeck().draw());
                game.getAlivePlayers()[counter].setOgCard2(game.getAlivePlayers()[counter].getCard2());
              }
              

            } else {

              // Blocker was bluffing, so blocker loses a card
              if (game.getAlivePlayers()[counter].getCard1().toString().equals("Dead")) {

                // Blocker's card1 is dead, so they lose their card2
                System.out.println(game.getAlivePlayers()[counter].getName() + " has lost the challenge and loses their " + game.getAlivePlayers()[counter].getCard2().toString());
                game.getAlivePlayers()[counter].setCard2(new Dead());

              } else {

                // Blocker's card1 is alive, so they lose their card1
                System.out.println(game.getAlivePlayers()[counter].getName() + " has lost the challenge and loses their " + game.getAlivePlayers()[counter].getCard1().toString());
                game.getAlivePlayers()[counter].setCard1(new Dead());

              }

              // User's duke is sucessful and user gains 3 coins
              System.out.println(user.getName() + "\'s Duke was sucessful. They gain 3 coins.");
              user.setNumCoins(user.getNumCoins() + 2);
              System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());

              // User wins the challenge, so their revealed Duke is swapped out
              System.out.println(user.getName() + " wins the challenge, so their Duke is swapped with a card in the deck\n");
              game.getDeck().addCard(new Duke());

              // Checks which of the cards the user had was the duke and replaces it with a new card
              if (user.getCard1().toString().equals("Duke")) {
                user.setCard1(game.getDeck().draw());
                user.setOgCard1(user.getCard1());
              } else {
                user.setCard2(game.getDeck().draw());
                user.setOgCard2(user.getCard2());
              }
            }

          } else {

            // User does not want to challenge
            System.out.println("\n" + user.getName() + " does not choose to challenge " + game.getAlivePlayers()[counter].getName() + "\'s block. \nDuke fails.");
          }

          // User's duke is resolved because a block has resolved
          resolved = true;
        }
      }

      counter++;
    }

    // Checks if nobody blocked
    if (!resolved) {
      System.out.println("Duke succeeds, " + user.getName() + " gains 3 coins");
      user.setNumCoins(user.getNumCoins() + 3);
      System.out.println(user.getName() + "'s new balance: " + user.getNumCoins());
    }
  }

  /** Returns a string representation of the Duke card
   * @return the name of the card
   */

  @Override
  public String toString() {
    return "Duke";
  }
}