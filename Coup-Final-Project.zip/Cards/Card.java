/**
* A Card interface with the methods , useAI, useHuman, and toString
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

interface Card {

  //Methods

  /** Allows the human player to perform an action
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */

  public void use(Player user, Game game, String check);

  /** Allows the AI to perform an action
   * @param user the player calling the method
   * @param game the game object the player was created in
   * @param check is used to differentiate between the two use methods
   */
  
  public void use(Player user, Game game, int check);
  
  /** Returns a string representation of the card
   * @return the name of the card
   */

  public String toString();

  
}