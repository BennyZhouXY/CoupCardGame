/**
* A deck object with a decklist
*
* @author  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou
* @version 1.0
* @since   2019-01-08 
*/

import java.util.*;

class Deck {

  // Declaration of state variables
  private Card[] deckList;

  /** Creates a Deck with 3 of each card, for a total of 15 cards
   */

  public Deck() {
    
    deckList = new Card[15];

    for (int i = 0; i < 3; i++) {
      Card card = new Captain();
      deckList[i * 5] = card;
      
      card = new Assassin();
      deckList[i * 5 + 1] = card;

      card = new Contessa();
      deckList[i * 5 + 2] = card;

      card = new Ambassador();
      deckList[i * 5 + 3] = card;

      card = new Duke();
      deckList[i * 5 + 4] = card;

    }
  }



  //Methods

  /** Randomly rearranges the order of the cards in the deck
   */

  public void shuffle() {

    // Creates a random object
    Random rndm = new Random();

    // Creates a temporary card to hold a card
    Card holder;
    int random = 0;

    // Uses the Fisher-Yates shuffle to shuffle the deck
    for (int i = deckList.length - 1; i > 0; i--) {

      // Chooses an index for the card at index i to be swapped with
      random = rndm.nextInt(i + 1);

      // Stores the card at the randomly selected index
      holder = deckList[random];

      // Overwrites the card at the randomly selected index with the card at index i
      deckList[random] = deckList[i];

      // Replaces the card at index i with the card at the randomly selected index
      deckList[i] = holder;
    }
  }



  /** Returns the first card in the deck and removes it from the deck
   * @return the card at the top of the deck
   */

  public Card draw() {

    // Gets the card at the top of the deckList
    Card drawnCard = this.deckList[0];
    
    // Moves the deckList up one index
    Card[] tempDeck = new Card[this.deckList.length - 1];
    for (int i = 0; i < tempDeck.length; i++) {
      tempDeck[i] = this.deckList[i + 1];
    }
    this.deckList = tempDeck;
    
    // Returns the stored card
    return drawnCard;
  }



  /** Adds a card to the deck
   * @param card the card
   */

  public void addCard(Card card) {

    // Creates a new array of one size larger
    Card[] tempDeck = new Card[this.deckList.length + 1];
    
    // Copies the original deckList into the temporary deckList
    for (int i = 0; i < this.deckList.length; i++) {
      tempDeck[i] = this.deckList[i];
    }

    // Adds the new card at the end of the temporary deckList
    tempDeck[this.deckList.length] = card;
    
    // Copies the temporary deckList back into the original deckList
    this.deckList = tempDeck;
  }



  /** Gets the deck's size
   * @return number of cards in the deck
   */
   
  public int getSize() {
    return this.deckList.length;
  }

  /** Gets the list of cards in the deck
   * @return the list of cards in the deck
   */

  public Card[] getDeck(){
    return this.deckList;
  }

  /** Sets the list of cards in the deck
   * @param the array of cards
   */
  
  public void setDeck(Card[] deckList) {
    this.deckList = deckList;
  }
}