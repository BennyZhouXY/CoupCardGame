//Coup in Java, by Zexi Lv, Ting Wu, Brandon Ye, and Benny Zhou 


/**
* The main method, starts and ends the game
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

class Main { 
  public static void main(String[] args) {

    //Create new game 
    Game game = new Game();

    //Initialize and Declare variables
    Boolean gameActive = true;
    int nextPlayer = 0;
    Card card;
    Player[] alivePlayers;

    //Start game
    while(gameActive) 
    {
       
      // Runs game while there is at least two alive players and the game is still continuing
      while (game.getNumAlivePlayers() > 1 && gameActive) {

        // Get the index of the next player to go
        nextPlayer = game.getNextPlayer();

        // Updates the list of alive players
        alivePlayers = game.getAlivePlayers();

        // Get the card the player chooses
        card = alivePlayers[nextPlayer].pickAction(game);

        // Checks if pickActions returns a valid card 
        if (!(card.toString().equals("Dead"))) {

          // Uses a card and sends in a third parameter based on whether or not the player is a human
          if (alivePlayers[nextPlayer].getIsHuman()) {
            card.use(alivePlayers[nextPlayer], game, "");
          } else {
            card.use(alivePlayers[nextPlayer], game, 0);
          }
          
        } else {

          // Ends the game if a Dead card is returned
          gameActive = false;
        }

        // Ends turn, which updates turn number, the list of alive players, etc.
        game.endTurn();
      }

      // Checks to see if the game ended naturally with all players dying (gameActive is still true) or because the player wishes to exit the program (gameActive is false)
      if (gameActive) {

        // Prints ranking in endGame and determines if the user wants to play a new game
        if (game.endGame()) {

          // Clear screen somewhat and creates a new game
          System.out.println("____________________\n\n\n\n\n");
          game = new Game();
        } else {

          // Exits program because user does not want to play again
          gameActive = false;
        }
      }
    }
  }
}