/**
* A Player abstract class
*
* @author  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou
* @version 1.0
* @since   2019-01-08 
*/

abstract class Player{
  
  //Declare variables
  int numCoins;
  Card card1;
  Card card2;
  String name;
  int rank;
  Card[] actions;
  Boolean isAlive;
  Boolean isHuman;
  Card ogCard1;
  Card ogCard2;

  /** Creates a Player with the specified name and cards.
   * @param card1 is the first card.
   * @param card2 is the second card.
   * @param name is the name.
   */

  public Player(Card card1, Card card2, String name)
  {
    this.isHuman = false;
    this.actions = new Card[0];
    this.numCoins = 2;
    this.card1 = card1;
    this.card2 = card2;
    this.ogCard1 = card1;
    this.ogCard2 = card2;
    this.name = name;
    this.rank = 0;
    this.isAlive = true;
  }



  //Methods

  /** Gets the player's number of coins
   * @return the number of coins
   */

  public int getNumCoins(){
    return this.numCoins;
  }

  /** Gets the player's first card
   * @return the card
   */

  public Card getCard1(){
    return this.card1;
  }

  /** Gets the player's second card
   * @return the card
   */

  public Card getCard2(){
    return this.card2;
  }
  /** Gets the player's first card they had before it died
   * @return the card
   */

  public Card getOgCard1(){
    return this.card1;
  }

  /** Gets the player's second card they had before it died
   * @return the card
   */

  public Card getOgCard2(){
    return this.card2;
  }

  /** Gets the player's name
   * @return the name
   */

  public String getName(){
    return this.name;
  }

  /** Gets the player's rank
   * @return the rank
   */

  public int getRank(){
    return this.rank;
  }

  /** Gets if the player is alive or not
   * @return if the player is alive or not
   */
  
  public Boolean getIsAlive() {
    return this.isAlive;
  }

  /** Sets the player's number of coins
   * @param coins the new number of coins
   */

  public void setNumCoins(int numCoins){
    this.numCoins = numCoins;
  }

  /** Sets the player's first card
   * @param card1 the new card
   */

  public void setCard1(Card card1){
    this.card1 = card1;
  }

  /** Sets the player's second card
   * @param card2 the new card
   */

  public void setCard2(Card card2){
    this.card2 = card2;
  }

  /** Sets the player's first card they had before it died
   * @param card1 the new card
   */

  public void setOgCard1(Card ogCard1){
    this.ogCard1 = ogCard1;
  }

  /** Sets the player's second card they had before it died
   * @param card2 the new card
   */

  public void setOgCard2(Card ogCard2){
    this.ogCard2 = ogCard2;
  }

  /** Sets the player's name
   * @param name the new name
   */

  public void setName(String name){
    this.name = name;
  }

  /** Sets the player's rank
   * @param rank the new rank
   */

  public void setRank(int rank){
    this.rank = rank;
  }

  /** Sets if the player is alive or not
   * @param isAlive the new isAlive
   */

  public void setIsAlive(Boolean isAlive) {
    this.isAlive = isAlive;
  }
  
  /** Returns whether the player is human or not as a boolean
   */

  public Boolean getIsHuman()
  {
    return this.isHuman;
  }
  
  /** Returns the player's information as a string
   * @return all of the player's information
   */

  public String toString() {
    return (this.numCoins + ", " + this.card1.toString() + ", " + this.card2.toString() + ", " + this.name + ", " + this.rank + ", " + this.ogCard1.toString() + ", " + this.ogCard2.toString());
  }
  

  
  //Abstract methods to be inherited

  abstract Boolean block(Card card);
  abstract Boolean challenge();
  abstract Card pickAction(Game game);  
  abstract String getInfo();
}