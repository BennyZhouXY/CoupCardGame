/**
* An AggessiveAI object that extends the abstract class AI
*
* @author  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou
* @version 1.0
* @since   2019-01-08 
*/

import java.util.*;

class AggressiveAI extends AI{

  Random rndm = new Random();

  /** Creates an aggressive AI with the specified name and cards.
    * @param card1 is the first card.
    * @param card2 is the second card.
    * @param name is the name.
    */

  public AggressiveAI(Card card1, Card card2, String name) 
  {
    //Inherit variables from superclass AI
    super(card1, card2, name);
    
    // Initialization of variables
    this.isHuman = false;
    this.numCoins = 2;
    this.ogCard1 = this.card1;
    this.ogCard2 = this.card2;
    this.rank = 0;
    this.isAlive = true;
  }



  //Methods

  /** Determine the AI's possible actions, choose a random action, and return the card associated with that action.
   * @return the card the AI would like to use. 
   * @param game the game object the AI was created in.
   */

  public Card pickAction(Game game)
  {

    //Declare start of turn
    System.out.println("\n--------------------------------------\n " + name + "\'S TURN \n--------------------------------------\n");

    //If AI has 10 or more coins, AI must coup
    if(numCoins >= 10)
    {
      //Create temp array
      actions = new Card[]{new Coup()};
    }
    //Else, pick random action
    else
    {
      // Fills the AggressiveAI's actions array based on the number of coins they have
      if (numCoins >= 3)
      {
        if (numCoins >= 7)
        {
          actions = new Card[]{new Duke(), new Assassin(), new Captain(), new Coup()};
        }
        else
        {
          actions = new Card[]{new Duke(), new Assassin(), new Captain()};
        }
      } 
      else 
      {
        actions = new Card[]{new Duke(), new Captain()};
      }
    }

    // Returns a random action
    return actions[rndm.nextInt(actions.length)];
  }



  /** Return true if the AI has the appropriate card to block, and return true 50% of the time if they do not
   * @param card is the card to be block
   * @return whether the AI will block or not
   */

  public Boolean block(Card card) {
    
    // Checks if the AI can block using their cards
    if(logicalBlock(card))
    {
      return true;
    }

    // 50% chance to bluff blocking
    else if (rndm.nextInt(2) == 0) 
    { 
      return false;
    }
    return true;
  }

  

  /** Return true 75% of the time when deciding whether to challenge or not
   * @return whether the AI will challenge or not
   */

  public Boolean challenge() {

    // Challenges every 3/4 times
    if (rndm.nextInt(4) == 0) 
    { 
      return false;
    }
    return true;
  }

}