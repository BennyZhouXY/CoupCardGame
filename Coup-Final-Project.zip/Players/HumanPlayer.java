/**
* A HumanPlayer object that extends the abstract class Player
*
* @author  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou
* @version 1.0
* @since   2019-01-08 
*/

import java.util.*;

class HumanPlayer extends Player{

  //Declare and initialize a Random and a Scanner objects
  Random rndm = new Random();
  Scanner scanner = new Scanner(System.in);

  /** Creates a human player with the specified name and cards.
   * @param card1 is the first card.
   * @param card2 is the second card.
   * @param name is the name.
   */

  public HumanPlayer (Card card1, Card card2, String name)
  {
    //Inherit variables from superclass Player
    super(card1, card2, name);
    
    // Initialization of variables
    this.isHuman = true;
    this.numCoins = 2;
    this.ogCard1 = this.card1;
    this.ogCard2 = this.card2;
    this.rank = 0;
    this.isAlive = true;

    //Fill array of human player's possible actions with all actions
    this.actions = new Card[] {new Income(), new ForeignAid(), new Coup(), new Duke(), new Assassin(), new Ambassador(), new Captain()};
  }



  //Methods

  /** Ask the user to choose an action and return the associated card. If the action chosen does not involve using a card, perform action and return a dead card object.
   * @return the card the player would like to use. 
   * @param game the game object that the player was created in.
   */

  public Card pickAction(Game game)
  {
    //Declare start of turn
    System.out.println("\n-----------\n YOUR TURN \n-----------\n");

    Player p = game.getPlayers()[0];
 
    System.out.println("Balance: " + p.getNumCoins() + "\nCard 1: " + p.getCard1() + "\nCard 2: " + p.getCard2());
    //Prompt user for input
    System.out.println("\nWhat action would you like to take?\n\n1 - Income\n2 - Foreign Aid\n3 - Coup\n4 - Duke\n5 - Assassin\n6 - Ambassador\n7 - Captain\n8 - Assess the game state\n9 - View the rules of the game\n10 - Save the game\n11 - Exit the game\n");
    
    //Initializes the input variable
    int input = 0;

    do {
      // Ensures that user enters a integer
      try{ 
        //Check for valid input (integer from 1-11)
        System.out.print("Enter a valid number from 1-11: ");
        input = Integer.parseInt(scanner.nextLine());
      }catch (NumberFormatException ex) {
      
      }
    } while (!((input >=1) && (input <=11)));

    //If user selects a card, return that card
    if (input < 8){
      // Only pickable action is coup if >=10 coins
      if (numCoins >= 10 && input != 3) { // ???????????????????

        // Prompts user to enter coup and gets user to pick another action
        System.out.println("\nOnly pickable action is coup.");
        
        return pickAction(game);
        
      } else {

        // Returns the selected action
        return actions[input - 1];
      }
    }

    //Else if user selects assess the game state, print information of every player
    else if(input == 8)
    {
      Player[] Players = game.getPlayers();

      System.out.println("\n--------\nPLAYERS\n--------");
      for(int i = 0; i < Players.length; i ++)
      {
        profile(Players[i]);
      }

      return pickAction(game);
    }

    // Prints the rules and gets the user to pick another action
    else if(input == 9)
    {
      printRules();
      return pickAction(game);
    } 

    // Saves the game and gets the user to pick another action
    else if(input == 10)
    {
      game.save();
      return pickAction(game);
    }
    
    // If input is 11, returns a dead card which in main will be used as a signal to end the program
    return(new Dead()); 
  }

  /** Ask the user if they would like to block and return their choice.
   * @param card is the card to be blocked.
   * @return the user's choice
   */

  public Boolean block(Card card)
  {
    //Prompt user for input
    System.out.println("Would you like to attempt to block?\n\n1- Yes\n2- No ");

    //Check for valid input (integer from 1-2)
    int input = -1;
    scanner = new Scanner(System.in);

    //Checks user input
    input=checkInput(input);

    //Return user's choice as boolean
    if(input == 1)
    {
      return true;
    }
    return false;
  }

  /** Ask the user if they would like to challenge and return their choice.
   * @return the user's choice
   */

  public Boolean challenge()
  {
    //Prompt user for action
    System.out.println("Would you like to challenge?\n\n1- Yes\n2- No");
    int input = 0;

    //Checks user input
    input=checkInput(input);

    // Returns user's choice as a boolean
    if(input == 1)
    {
      return true;
    }
    return false;
  }

  /** Print the rules of Coup.
   */

  public void printRules()
  {
    System.out.println("\n\n---------------\nRULES OF COUP\n---------------\n\nIn Coup, you want to be the last player with one or more living cards in the game, with living cards being hidden to other players in the game and dead cards being revealed.\n\n\nEach player starts the game with two coins and two living cards. The fifteen card deck consists of three copies of five different characters, each with a unique set of powers:\n\n\nDuke: Take three coins from the treasury. Block someone from taking foreign aid.\n\nAssassin: Pay three coins and try to assassinate another player's character randomly.\n\nContessa: Block an assassination attempt against yourself, or block another player from using Duke.\n\nCaptain: Take two coins from another player, or block someone from stealing coins from you.\n\nAmbassador: Draw two character cards from the Court (the deck), choose which (if any) to exchange with your face-down characters, then return two. Block someone from stealing coins from you.\n\n\nOn your turn, you can take any of the non-block actions listed above, regardless of which characters you actually have in front of you, or you can take one of three other actions:\n\n\nIncome: Take one coin from the treasury.\n\nForeign aid: Take two coins from the treasury.\n\nCoup: Pay seven coins and launch a coup against an opponent, forcing that player to lose an influence randomly. (If you have ten coins or more, you must take this action.)\n\n\nWhen another player attempts to use an action that targets you, or if they attempt to use Duke or Foreign Aid, you can attempt to block. When you attempt to block an oppoenent's action, that character's action automatically fails unless the opponent challenges you. If the opponent challenges you,you must reveal the appropriate character with the appropriate block ability. If you cannot, a random card you own will be killed, but if you can, then your block will succeed, the opponent's original action will fail, a random card the opponent owns will be killed, and you must shuffle the card you revealed into the deck and draw a new card. Dead cards cannot be used, and if both of your characters are dead, you're out of the game.\n\n\nThe last player to still have one or more living cards wins the game!");
  }

  /** Print information about target player
   * @param target is the player who's info is to be printed
   */

  public void profile(Player target)
  {
    System.out.println(target.getInfo());
  }

  /** Returns the player's info
   * @return the player's info
   */
  
  public String getInfo()
  {
    // Checks if the human's first card is dead
    if (card1.toString().equals("Dead")) {
      // Prints the player's information
      return name + " - " + isAliveToString(isAlive) +":\n" + numCoins + " coins\nDead " + ogCard1.toString() + ", " + ogCard2.toString() + "\n";
    }

    // Prints the player's information
    return name + " - " + isAliveToString(isAlive) +":\n" + numCoins + " coins\n" + ogCard1.toString() + ", " + ogCard2.toString() + "\n";
    
  }


  /** Returns the users input after making sure they enter something acceptable
  * @param input is the variable used to store user input
  * @return input returns the users choice
  */
  
  public int checkInput(int input) {
    do {
      // Ensures that user enters a integer
      try{ 
        //Check for valid input (integer from 1-2)
        System.out.print("Enter a valid number from 1-2: ");
        input = Integer.parseInt(scanner.nextLine());
      }catch (NumberFormatException ex) {
      
      }
    } while (!((input >=1) && (input <=2)));
    return input;
  }

  /** Returns whether or not the player is alive based on their isAlive boolean
  * @param isAlive is whhether or not the player is alive
  * @return if the player is alive or dead
  */

  public String isAliveToString (boolean isAlive) {
    if (isAlive) {
      return "Alive";
    }
    return "Dead";
  }
}