/**
* A WildcardAI object that extends the abstract class AI
*
* @authors  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou 
* @version 1.0
* @since   2019-01-08 
*/

import java.util.*;

class WildcardAI extends AI{

  //Declare random object
  Random rndm = new Random();
  
  /** Creates a wildcard AI with the specified name and cards.
   * 
   * @param card1 is the first card.
   * @param card2 is the second card.
   * @param name is the name.
   */

  public WildcardAI (Card card1, Card card2, String name) 
  {
    //Inherit variables from superclass AI
    super(card1, card2, name);

    // Initialization of variables
    this.isHuman = false;
    this.numCoins = 2;
    this.ogCard1 = this.card1;
    this.ogCard2 = this.card2;
    this.rank = 0; // initialized as 0
    this.isAlive = true;

    //Fill array of wildcard AI's possible actions with all actions that can occur regardless of coins

    Card income = new Income();
    Card foreignAid = new ForeignAid();
    Card duke = new Duke();
    Card ambassador = new Ambassador();
    Card actions[] = new Card[]{income, foreignAid, duke, ambassador}; 
  }



  //Methods

  /** Determine the AI's possible actions, choose a random action, and return the card associated with that action.
   * @return the card the player would like to use. 
   * @param game the game object the AI was created in.
   */

  public Card pickAction(Game game)
  {
    //Declare start of turn
    System.out.println("\n------------------------------\n " + name + "\'S TURN \n------------------------------\n");

    // Cards to be used to fill the action array
    Card ambassador = new Ambassador();
    Card duke = new Duke();
    Card income = new Income();
    Card foreignAid = new ForeignAid();
    Card assassin = new Assassin();
    Card captain = new Captain();
    Card coup = new Coup();

    //If AI has 10 or more coins, AI must coup
    if(numCoins >= 10)
    {
      actions = new Card[]{coup};
    }

    //Else if AI has 7 or more coins, add coup and assassin to possible actions
    else if(numCoins >= 7)
    {

      actions = new Card[]{income, foreignAid, duke, ambassador, coup, assassin}; 
    }

    //Else if AI has 3 or more coins, only add assassin to possible actions
    else if (numCoins >= 3)
    {
      actions = new Card[]{income, foreignAid, duke, ambassador, assassin};
    } 
    else
    {
      actions = new Card[] {income, foreignAid, duke, ambassador};
    }

    //Return random action
    Card toUse = actions[rndm.nextInt(actions.length)];
    return toUse;
  }



  /** Return true 50% of the time when deciding whether to block or not
   * @param card is the card to be blocked
   * @return whether the AI will block or not
   */

  public Boolean block(Card card)
  {
    if(rndm.nextInt(2) == 1)
    {
      return true;
    }

    return false;
  }



  /** Return true 50% of the time when deciding whether to challenge or not
   * @return whether the AI will challenge or not
   */
  public Boolean challenge()
  {
    if(rndm.nextInt(2) == 1)
    {
      return true;
    }

    return false;
  }
}