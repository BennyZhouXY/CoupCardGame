/**
* A Passive AI object that extends the AI abstract class
*
* @author  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou
* @version 1.0
* @since   2019-01-08 
*/

import java.util.*;

class PassiveAI extends AI{

  // Declare and initialize Random object
  Random rndm = new Random();
  
  /** Creates a passive AI with the specified name and cards.
    * 
    * @param card1 is the first card.
    * @param card2 is the second card.
    * @param name is the name.
    */

  public PassiveAI (Card card1, Card card2, String name) 
  {
    //Inherit variables from superclass AI
    super(card1, card2, name);
    
    // Initialization of variables
    this.isHuman = false;
    this.numCoins = 2;
    this.ogCard1 = this.card1;
    this.ogCard2 = this.card2;
    this.rank = 0;
    this.isAlive = true;
    actions = new Card[] {new Income(), new Coup(), card1, card2};
  }

  

  //Methods

  /** Determine the AI's possible actions, choose a random action, and return the card associated with that action.
   * @return the card the AI would like to use. 
   * @param game the game object the AI was created in.
   */

  public Card pickAction(Game game)
  {
    //Declare start of turn
    System.out.println("\n------------------------------\n " + name + "\'s TURN \n------------------------------\n");

    // Checks if 10+ coins (must coup)
    if (numCoins >= 10)
    {
      actions = new Card[]{new Coup()};
    }
    else
    {
      // Checks if card1 and card2 are usable
      Boolean card1Usable = isUsable(card1, game);
      Boolean card2Usable = isUsable(card2, game);

      // Checks if the passive ai can use coup
      if (numCoins > 7)
      {
        // Adds the cards to the actions array
        if (card1Usable && card2Usable)
        {
          actions = new Card[]{new Income(), new Coup(), card1, card2};
        }
        else if (card1Usable && !card2Usable)
        {
          // Only card1 is usable
          actions = new Card[]{new Income(), new Coup(), card1};
        }
        else if (!card1Usable && card2Usable)
        {
          // Only card2 is usable
          actions = new Card[]{new Income(), new Coup(), card2};
        }
        else
        {
          // Neither card is usable
          actions = new Card[]{new Income(), new Coup()};
        }
      }
      else 
      { 
        // Adds the cards to the actions array, coup is not usable
        if (card1Usable && card2Usable)
        {
          // Both cards are usable
          actions = new Card[]{new Income(), card1, card2};
        }
        else if (card1Usable && !card2Usable)
        {
          // Only card1 is usable
          actions = new Card[]{new Income(), card1};
        }
        else if (!card1Usable && card2Usable)
        {
          // Only card2 is usable
          actions = new Card[]{new Income(), card2};
        }
        else
        {
          // Neither card1 or card2 are usable, so only possible action is income
          actions = new Card[]{new Income()};
        }
      }
    }

    // Picks a random action from the actions array and returns it
    return actions[rndm.nextInt(actions.length)];
  }



  /** Checks if the given card is usable without risk of losing against a block/challenge
   * @return whether the card is usable or not as a boolean
   * @param card the given card
   * @param game the game object the AI was created in.
   */

  public Boolean isUsable(Card card, Game game)
  {
    // Checks if the card is a Contessa or Dead
    if (card.toString().equals("Contessa") || card.toString().equals("Dead"))
    {
      return false;
    }

    // Checks if the card is an Assassin
    else if (card.toString().equals("Assassin"))
    {
      // Checks if the Assassin is usable
      if (numCoins >= 3)
      {
        return true;
      }
      return false;
    }
    
    // The remaining cards (except for Captain) don't have conditions on their usage, and whether Captain can be used or not is determined in the Captain's class
    return true;
  }



  /** Return true if the AI has the appropriate card to block, otherwise return false
   * @return whether the AI will block or not
   */

  public Boolean block(Card card) {
    return(logicalBlock(card));
  }

  

  /** The passive AI will never challenge, therefore return false
   * @return false
   */

  public Boolean challenge()
  {
    return false;
  }
}