/**
* An AI abstract class that extends the abstract class Player
*
* @author  Zexi Lv, Ting Wu, Brandon Ye, Benny Zhou
* @version 1.0
* @since   2019-01-08 
*/

abstract class AI extends Player{

  /** Creates an AI with the specified name and cards.
   * @param card1 is the first card.
   * @param card2 is the second card.
   * @param name is the name.
   */

  public AI (Card card1, Card card2, String name)
  {
    //Inherit variables from superclass Player
    super(card1, card2, name);

    //Initialize variables
    this.numCoins = 2;
    this.ogCard1 = this.card1;
    this.ogCard2 = this.card2;
    this.rank = 0;
    this.isAlive = true;
  }



  //Methods

  /** Gets the AI's information from the perspective of the player
   * @return the string containing information
   */

  public String getInfo() 
  {
    //Determines whether AI is dead or alive
    String isAliveStr = "";

    if(this.isAlive)
    {
      isAliveStr = "Alive";
    }
    else
    {
      isAliveStr = "Dead";
    }

    // Determine which cards to display
    String cards = "";

    if (card1.toString().equals("Dead"))
    {
      // Card1 is dead
      cards += "Dead " + ogCard1.toString() + ", ";
    }
    else
    {
      // Card1 is still alive, so it is hidden from the human player
      cards += "1 hidden card, ";
    }
    if (card2.toString().equals("Dead")) 
    {
      // Card2 is dead
      cards += "Dead " + ogCard2.toString();
    }
    else 
    {
      // Card2 is still alive, so it is hidden from the human player
      cards += "1 hidden card";
    }

    //Return name, dead or alive, number of coins, and information about cards
    return name + " - " + isAliveStr +  ":\n" + numCoins + " coins\n" + cards + "\n";
  }



  /** Determine and run the appropriate canBlock() method and return true if the AI decides to block
   * @param card is the card the AI is deciding to block
   * @return whether the AI will block or not
   */

  public Boolean logicalBlock(Card card) {

    // Determines the type of block to run based on the card's name
    if (card.toString().equals("Captain")) {

      Captain captain = new Captain();
      return canBlock(captain);

    } else if (card.toString().equals("Assassin")) {

      Assassin assassin = new Assassin();
      return canBlock(assassin);

    } else if (card.toString().equals("Duke")) {

      Duke duke = new Duke();
      return canBlock(duke);

    }

    ForeignAid fAid = new ForeignAid();
    return canBlock(fAid);
  }



  /** Determine and return true if AI has the possesses the correct card to block Captain
   * @param captain is the captain to be blocked
   * @return whether the AI will block or not
   */

  public Boolean canBlock(Captain captain)
  {
    // Checks if either card1 or card2 are Ambassador or Duke
    if (card1.toString().equals("Duke") || card2.toString().equals("Duke") || card1.toString().equals("Ambassador") || card2.toString().equals("Ambassador"))
    {
      return true;
    }

    // Doesn't block if it can't block
    return false;
  }


  
  /** Determine and return true if AI has the possesses the correct card to block Assassin
   * @param assassin is the assassin to be blocked
   * @return whether the AI will block or not
   */

  public Boolean canBlock(Assassin assassin)
  {
    // Checks if either card1 or card2 are Contessa
    if (card1.toString().equals("Contessa") || card2.toString().equals("Contessa"))
    {
      return true;
    }

    // Doesn't block if it can't block
    return false;
  }



  /** Determine and return true if AI has the possesses the correct card to block Duke
   * @param duke is the duke to be blocked
   * @return whether the AI will block or not
   */

  public Boolean canBlock(Duke duke){

    // Checks if either card1 or card2 are Contessa
    if ((card1.toString().equals("Contessa") || card2.toString().equals("Contessa"))){
      return true;
    }

    // Doesn't block if it can't block
    return false;
  }

  

  /** Determine and return true if AI has the possesses the correct card to block Foreign Aid
   * @param fAid is the foreign aid to be blocked
   * @return whether the AI will block or not
   */

  public Boolean canBlock(ForeignAid fAid){

    // Checks if either card1 or card2 are Duke
    if ((card1.toString().equals("Duke") || card2.toString().equals("Duke"))){
      return true;
    }

    // Doesn't block if it can't block
    return false;
  }
}